package com.example.vb3cluster;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.method.ScrollingMovementMethod;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int REQ_PICK = 1;
    private static final int REQ_SAVE = 2;
    private static final int N = 8;
    private static final String[] LABEL = {
            "cpu0 A55", "cpu1 A55", "cpu2 A55", "cpu3 A55",
            "cpu4 A55", "cpu5 A55", "cpu6 A76", "cpu7 A76"};
    private static final String[] CNAME = {"C0 kecil", "C1 tengah", "C2 besar"};

    private final RadioGroup[] groups = new RadioGroup[N];
    private int[] base = {0, 0, 0, 0, 0, 0, 2, 2};
    private byte[] img;
    private byte[] result;
    private TextView info;
    private TextView status;
    private boolean busy;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(32), dp(16), dp(24));
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("Konversi vendor_boot ke 3 cluster");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        TextView notes = new TextView(this);
        notes.setText("- Pemindahan core hanya mengubah DTB (capacity, performance-domains, cpu-map); "
                + "cek stabilitas & thermal sendiri.\n"
                + "- Cluster tengah memakai performance-domain ke-3 (kemungkinan tabel CCI).\n"
                + "- Image bertanda tangan AVB: flash vbmeta dengan --disable-verification "
                + "(atau bootloader terbuka).\n"
                + "- Driver cpufreq & firmware mcupm harus mendukung 3 domain.\n"
                + "- Backup vendor_boot asli dulu.");
        notes.setTypeface(android.graphics.Typeface.MONOSPACE);
        notes.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        notes.setPadding(0, dp(12), 0, dp(12));
        root.addView(notes);

        TextView h = new TextView(this);
        h.setText("Atur core per cluster");
        h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        h.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(h);

        info = new TextView(this);
        info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        info.setTextColor(0xFF888888);
        info.setPadding(0, 0, 0, dp(8));
        root.addView(info);

        for (int i = 0; i < N; i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView l = new TextView(this);
            l.setText(LABEL[i]);
            l.setTypeface(android.graphics.Typeface.MONOSPACE);
            l.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            l.setLayoutParams(new LinearLayout.LayoutParams(dp(84), LinearLayout.LayoutParams.WRAP_CONTENT));
            row.addView(l);
            RadioGroup g = new RadioGroup(this);
            g.setOrientation(RadioGroup.HORIZONTAL);
            for (int c = 0; c < 3; c++) {
                RadioButton rb = new RadioButton(this);
                rb.setText(CNAME[c]);
                rb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                rb.setId(View.generateViewId());
                g.addView(rb);
            }
            g.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    updateInfo();
                }
            });
            groups[i] = g;
            row.addView(g);
            root.addView(row);
        }
        applySelection(base);

        root.addView(button("RESET KE SUSUNAN BASE", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applySelection(base);
            }
        }));
        root.addView(button("PILIH VENDOR_BOOT.IMG", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pick();
            }
        }));
        root.addView(button("KONVERSI & SIMPAN", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convert();
            }
        }));
        root.addView(button("KEMBALI", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        }));

        status = new TextView(this);
        status.setText("Belum ada file dipilih.");
        status.setPadding(0, dp(12), 0, 0);
        status.setMovementMethod(new ScrollingMovementMethod());
        root.addView(status);

        setContentView(sv);
    }

    private Button button(String text, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(text);
        bt.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        bt.setLayoutParams(lp);
        return bt;
    }

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics()));
    }

    private void applySelection(int[] sel) {
        for (int i = 0; i < N; i++) {
            ((RadioButton) groups[i].getChildAt(sel[i])).setChecked(true);
        }
        updateInfo();
    }

    private int[] currentSelection() {
        int[] r = new int[N];
        for (int i = 0; i < N; i++) {
            for (int c = 0; c < 3; c++) {
                if (((RadioButton) groups[i].getChildAt(c)).isChecked()) r[i] = c;
            }
        }
        return r;
    }

    private static String count(int[] s) {
        int[] n = new int[3];
        for (int v : s) n[v]++;
        return n[0] + "-" + n[1] + "-" + n[2];
    }

    private void updateInfo() {
        info.setText("Susunan: " + count(currentSelection())
                + " core (kecil-tengah-besar), bawaan base: " + count(base));
    }

    private void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_PICK);
    }

    private void convert() {
        if (img == null) {
            Toast.makeText(this, "Pilih vendor_boot.img dulu", Toast.LENGTH_SHORT).show();
            return;
        }
        if (busy) return;
        busy = true;
        status.setText("Mengonversi...");
        final int[] sel = currentSelection();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    result = VendorBootConverter.convert(img, sel);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            busy = false;
                            status.setText("Konversi selesai (" + count(sel) + "). Pilih lokasi simpan...");
                            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                            i.addCategory(Intent.CATEGORY_OPENABLE);
                            i.setType("application/octet-stream");
                            i.putExtra(Intent.EXTRA_TITLE, "vendor_boot_3cluster.img");
                            startActivityForResult(i, REQ_SAVE);
                        }
                    });
                } catch (final Throwable t) {
                    fail(t);
                }
            }
        }).start();
    }

    private void fail(final Throwable t) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                busy = false;
                status.setText("Gagal: " + t.getMessage());
            }
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        if (req == REQ_PICK) {
            status.setText("Membaca file...");
            busy = true;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        final byte[] bytes = readAll(uri);
                        final int[] det = VendorBootConverter.detect(bytes);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                busy = false;
                                img = bytes;
                                if (det != null && det.length == N) {
                                    base = det;
                                    applySelection(base);
                                }
                                status.setText("Dimuat: " + (bytes.length / 1024) + " KB. Susunan terdeteksi "
                                        + (det != null ? count(det) : "?") + ".");
                            }
                        });
                    } catch (final Throwable t) {
                        img = null;
                        fail(t);
                    }
                }
            }).start();
        } else if (req == REQ_SAVE && result != null) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        OutputStream os = getContentResolver().openOutputStream(uri, "wt");
                        os.write(result);
                        os.close();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                status.setText("Tersimpan (" + (result.length / 1024) + " KB).");
                            }
                        });
                    } catch (final Throwable t) {
                        fail(t);
                    }
                }
            }).start();
        }
    }

    private byte[] readAll(Uri uri) throws Exception {
        long size = -1;
        Cursor c = getContentResolver().query(uri, null, null, null, null);
        if (c != null) {
            try {
                int idx = c.getColumnIndex(OpenableColumns.SIZE);
                if (idx >= 0 && c.moveToFirst()) size = c.getLong(idx);
            } finally {
                c.close();
            }
        }
        InputStream in = getContentResolver().openInputStream(uri);
        try {
            if (size > 0 && size < Integer.MAX_VALUE) {
                byte[] buf = new byte[(int) size];
                new DataInputStream(in).readFully(buf);
                return buf;
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] tmp = new byte[1 << 16];
            int n;
            while ((n = in.read(tmp)) > 0) bos.write(tmp, 0, n);
            return bos.toByteArray();
        } finally {
            in.close();
        }
    }
}
