package com.example.vb3cluster;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Parser + serializer FDT (device tree biner) minimal, tanpa dependensi Android. */
final class Fdt {
    static final int MAGIC = 0xd00dfeed;

    static final class Prop {
        String name;
        byte[] val;
        Prop(String n, byte[] v) { name = n; val = v; }
    }

    static final class Node {
        String name;
        final List<Prop> props = new ArrayList<>();
        final List<Node> kids = new ArrayList<>();
        Node(String n) { name = n; }

        Prop prop(String n) {
            for (Prop p : props) if (p.name.equals(n)) return p;
            return null;
        }
        void set(String n, byte[] v) {
            Prop p = prop(n);
            if (p != null) p.val = v; else props.add(new Prop(n, v));
        }
        Node kid(String n) {
            for (Node k : kids) if (k.name.equals(n)) return k;
            return null;
        }
    }

    Node root;
    byte[] rsv;
    int version, lastComp, bootCpu;

    static Fdt parse(byte[] b, int base) {
        ByteBuffer bb = ByteBuffer.wrap(b);
        if (bb.getInt(base) != MAGIC) throw new IllegalArgumentException("Bukan FDT");
        int offStruct = bb.getInt(base + 8);
        int offStr = bb.getInt(base + 12);
        int offRsv = bb.getInt(base + 16);
        Fdt f = new Fdt();
        f.version = bb.getInt(base + 20);
        f.lastComp = bb.getInt(base + 24);
        f.bootCpu = bb.getInt(base + 28);
        f.rsv = Arrays.copyOfRange(b, base + offRsv, base + offStruct);
        int p = base + offStruct;
        int strBase = base + offStr;
        List<Node> stack = new ArrayList<>();
        while (true) {
            int t = bb.getInt(p);
            p += 4;
            if (t == 1) {
                int e = p;
                while (b[e] != 0) e++;
                String name = new String(b, p, e - p, StandardCharsets.UTF_8);
                p += ((e - p + 1) + 3) & ~3;
                Node n = new Node(name);
                if (stack.isEmpty()) f.root = n; else stack.get(stack.size() - 1).kids.add(n);
                stack.add(n);
            } else if (t == 2) {
                stack.remove(stack.size() - 1);
            } else if (t == 3) {
                int len = bb.getInt(p), no = bb.getInt(p + 4);
                p += 8;
                byte[] v = Arrays.copyOfRange(b, p, p + len);
                p += (len + 3) & ~3;
                int s = strBase + no, e = s;
                while (b[e] != 0) e++;
                stack.get(stack.size() - 1).props.add(new Prop(new String(b, s, e - s, StandardCharsets.UTF_8), v));
            } else if (t == 4) {
                // NOP
            } else if (t == 9) {
                break;
            } else {
                throw new IllegalArgumentException("Token FDT tidak dikenal: " + t);
            }
        }
        return f;
    }

    byte[] serialize() {
        Map<String, Integer> smap = new LinkedHashMap<>();
        ByteArrayOutputStream strtab = new ByteArrayOutputStream();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        write(root, out, strtab, smap);
        put(out, 9);
        byte[] st = out.toByteArray();
        byte[] sr = strtab.toByteArray();
        int offRsv = 40;
        int offStruct = offRsv + rsv.length;
        int offStr = offStruct + st.length;
        int total = offStr + sr.length;
        ByteBuffer h = ByteBuffer.allocate(40);
        h.putInt(MAGIC).putInt(total).putInt(offStruct).putInt(offStr).putInt(offRsv)
                .putInt(version).putInt(lastComp).putInt(bootCpu).putInt(sr.length).putInt(st.length);
        ByteArrayOutputStream res = new ByteArrayOutputStream(total);
        res.write(h.array(), 0, 40);
        res.write(rsv, 0, rsv.length);
        res.write(st, 0, st.length);
        res.write(sr, 0, sr.length);
        return res.toByteArray();
    }

    private static void put(ByteArrayOutputStream o, int v) {
        o.write(v >>> 24); o.write(v >>> 16); o.write(v >>> 8); o.write(v);
    }

    private static void pad(ByteArrayOutputStream o, int len) {
        for (int i = 0; i < ((-len) & 3); i++) o.write(0);
    }

    private static void write(Node n, ByteArrayOutputStream o, ByteArrayOutputStream strtab, Map<String, Integer> smap) {
        put(o, 1);
        byte[] nm = n.name.getBytes(StandardCharsets.UTF_8);
        o.write(nm, 0, nm.length);
        o.write(0);
        pad(o, nm.length + 1);
        for (Prop p : n.props) {
            Integer id = smap.get(p.name);
            if (id == null) {
                id = strtab.size();
                smap.put(p.name, id);
                byte[] s = p.name.getBytes(StandardCharsets.UTF_8);
                strtab.write(s, 0, s.length);
                strtab.write(0);
            }
            put(o, 3);
            put(o, p.val.length);
            put(o, id);
            o.write(p.val, 0, p.val.length);
            pad(o, p.val.length);
        }
        for (Node k : n.kids) write(k, o, strtab, smap);
        put(o, 2);
    }

    static byte[] be32(int v) {
        return new byte[]{(byte) (v >>> 24), (byte) (v >>> 16), (byte) (v >>> 8), (byte) v};
    }
}
