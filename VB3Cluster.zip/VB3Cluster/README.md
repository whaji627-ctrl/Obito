# VB 3 Cluster

Aplikasi Android untuk mengubah topologi CPU di `vendor_boot.img` (header v3/v4) menjadi 3 cluster.
Cluster: C0 kecil (domain 0), C1 tengah (domain ke-3), C2 besar (domain 1). Yang diubah hanya DTB:
`cpu-map`, `performance-domains`, `capacity-dmips-mhz`, dan (bila perlu) `performance-domain2` pada performance-controller.

## Build APK
**Android Studio:** File > Open folder ini > Build > Build APK(s). Hasil: `app/build/outputs/apk/debug/app-debug.apk`.

**Dari HP / tanpa PC:** upload folder ini ke repo GitHub, lalu Actions > "Build APK" > Run workflow,
unduh artifact `VB3Cluster-debug-apk`.

## Catatan
- Backup vendor_boot asli dulu. Flash vbmeta dengan `--disable-verification` bila perlu.
- Domain ke-3 kemungkinan tabel CCI, jadi cpu "tengah" belum tentu punya clock sendiri.
- Inti konverter (`Fdt.java`, `VendorBootConverter.java`) sudah diuji pada image OrangeFox X6882:
  hasilnya identik byte-per-byte dengan versi Python, termasuk jalur geser section + update footer AVB.
