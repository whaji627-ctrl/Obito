package com.example.vb3cluster;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Mengubah topologi CPU (cpu-map, performance-domains, capacity) di DTB dalam vendor_boot.img (header v3/v4).
 * Cluster: 0 = kecil, 1 = tengah, 2 = besar.
 */
public final class VendorBootConverter {
    /** performance-domain per cluster: kecil=0, tengah=2 (domain ke-3), besar=1. */
    static final int[] DOM = {0, 2, 1};
    /** capacity-dmips-mhz per cluster. */
    static final int[] CAP = {383, 640, 1024};

    private VendorBootConverter() {}

    // ---------- util ----------
    private static int le32(byte[] b, int o) { return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).getInt(o); }
    private static void putLe32(byte[] b, int o, int v) { ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).putInt(o, v); }
    private static int be32(byte[] b, int o) { return ByteBuffer.wrap(b).getInt(o); }
    private static void putBe32(byte[] b, int o, int v) { ByteBuffer.wrap(b).putInt(o, v); }
    private static long be64(byte[] b, int o) { return ByteBuffer.wrap(b).getLong(o); }
    private static void putBe64(byte[] b, int o, long v) { ByteBuffer.wrap(b).putLong(o, v); }
    private static int align(int x, int page) { return (x + page - 1) / page * page; }

    private static final class Layout {
        int page, oDtb, dtbSize, oldSlot, oAfter;
    }

    private static Layout layout(byte[] img) {
        if (img.length < 2128 || !"VNDRBOOT".equals(new String(img, 0, 8))) {
            throw new IllegalArgumentException("Bukan vendor_boot.img (magic VNDRBOOT tidak ditemukan)");
        }
        int ver = le32(img, 8);
        if (ver < 3) throw new IllegalArgumentException("Versi header vendor_boot " + ver + " tidak didukung (butuh v3/v4)");
        Layout l = new Layout();
        l.page = le32(img, 12);
        int rdsz = le32(img, 24);
        int hs = le32(img, 2096);
        l.dtbSize = le32(img, 2100);
        int oRd = align(hs, l.page);
        l.oDtb = oRd + align(rdsz, l.page);
        l.oldSlot = align(l.dtbSize, l.page);
        l.oAfter = l.oDtb + l.oldSlot;
        if (l.dtbSize <= 0 || l.oDtb + l.dtbSize > img.length) throw new IllegalArgumentException("Ukuran DTB di header tidak valid");
        return l;
    }

    // ---------- baca susunan sekarang ----------
    /** Mengembalikan cluster (0/1/2) tiap core menurut performance-domains di DTB, atau null bila tidak ketemu. */
    public static int[] detect(byte[] img) {
        Layout l = layout(img);
        byte[] sec = Arrays.copyOfRange(img, l.oDtb, l.oDtb + l.dtbSize);
        List<byte[]> blobs = blobs(sec);
        for (byte[] raw : blobs) {
            if (raw.length < 4 || be32(raw, 0) != Fdt.MAGIC) continue;
            Fdt f = Fdt.parse(raw, 0);
            Fdt.Node cpus = f.root.kid("cpus");
            if (cpus == null) continue;
            List<Fdt.Node> cpu = cpuNodes(cpus);
            int[] res = new int[cpu.size()];
            for (int i = 0; i < res.length; i++) {
                Fdt.Prop pd = cpu.get(i).prop("performance-domains");
                int dom = (pd != null && pd.val.length >= 8) ? be32(pd.val, 4) : 0;
                res[i] = dom == DOM[2] ? 2 : (dom == DOM[1] ? 1 : 0);
            }
            return res;
        }
        return null;
    }

    private static List<byte[]> blobs(byte[] sec) {
        List<byte[]> r = new ArrayList<>();
        int m = be32(sec, 0);
        if (m == Fdt.MAGIC) {
            r.add(sec);
        } else if (m == 0xd7b7ab1e) {
            int entSize = be32(sec, 12), cnt = be32(sec, 16), entOff = be32(sec, 20);
            for (int i = 0; i < cnt; i++) {
                int eo = entOff + i * entSize;
                int size = be32(sec, eo), off = be32(sec, eo + 4);
                r.add(Arrays.copyOfRange(sec, off, off + size));
            }
        } else {
            throw new IllegalArgumentException("Format bagian DTB tidak dikenal");
        }
        return r;
    }

    private static List<Fdt.Node> cpuNodes(Fdt.Node cpus) {
        List<Fdt.Node> r = new ArrayList<>();
        for (Fdt.Node k : cpus.kids) if (k.name.startsWith("cpu@")) r.add(k);
        return r;
    }

    // ---------- patch pohon DTB ----------
    static void patchTree(Fdt f, int[] cl) {
        Fdt.Node cpus = f.root.kid("cpus");
        if (cpus == null) throw new IllegalArgumentException("Node /cpus tidak ditemukan");
        List<Fdt.Node> cpu = cpuNodes(cpus);
        if (cpu.size() != cl.length) {
            throw new IllegalArgumentException("DTB punya " + cpu.size() + " core, bukan " + cl.length);
        }
        boolean useMid = false;
        List<List<Integer>> members = new ArrayList<>();
        for (int c = 0; c < 3; c++) members.add(new ArrayList<Integer>());
        for (int i = 0; i < cl.length; i++) {
            if (cl[i] < 0 || cl[i] > 2) throw new IllegalArgumentException("Cluster tidak valid");
            members.get(cl[i]).add(i);
            if (cl[i] == 1) useMid = true;
        }
        for (int i = 0; i < cpu.size(); i++) {
            Fdt.Node n = cpu.get(i);
            Fdt.Prop pd = n.prop("performance-domains");
            byte[] ctrl = (pd != null && pd.val.length >= 4) ? Arrays.copyOfRange(pd.val, 0, 4) : null;
            if (ctrl == null) throw new IllegalArgumentException("cpu" + i + " tidak punya performance-domains");
            byte[] v = new byte[8];
            System.arraycopy(ctrl, 0, v, 0, 4);
            System.arraycopy(Fdt.be32(DOM[cl[i]]), 0, v, 4, 4);
            n.set("performance-domains", v);
            n.set("capacity-dmips-mhz", Fdt.be32(CAP[cl[i]]));
        }
        // cpu-map
        Fdt.Node map = cpus.kid("cpu-map");
        if (map == null) { map = new Fdt.Node("cpu-map"); cpus.kids.add(map); }
        map.kids.clear();
        int idx = 0;
        for (int c = 0; c < 3; c++) {
            if (members.get(c).isEmpty()) continue;
            Fdt.Node cn = new Fdt.Node("cluster" + idx++);
            int core = 0;
            for (int cpuIdx : members.get(c)) {
                Fdt.Prop ph = cpu.get(cpuIdx).prop("phandle");
                if (ph == null) ph = cpu.get(cpuIdx).prop("linux,phandle");
                if (ph == null) throw new IllegalArgumentException("cpu" + cpuIdx + " tidak punya phandle");
                Fdt.Node co = new Fdt.Node("core" + core++);
                co.props.add(new Fdt.Prop("cpu", ph.val.clone()));
                cn.kids.add(co);
            }
            map.kids.add(cn);
        }
        // domain ke-3 pada performance-controller
        if (useMid) ensureThirdDomain(f.root);
    }

    private static Fdt.Node findPerfController(Fdt.Node n) {
        if (n.prop("#performance-domain-cells") != null && n.prop("reg") != null) return n;
        for (Fdt.Node k : n.kids) {
            Fdt.Node r = findPerfController(k);
            if (r != null) return r;
        }
        return null;
    }

    private static void ensureThirdDomain(Fdt.Node root) {
        Fdt.Node pc = findPerfController(root);
        if (pc == null) throw new IllegalArgumentException("Node performance-controller tidak ditemukan");
        Fdt.Prop reg = pc.prop("reg");
        Fdt.Prop names = pc.prop("reg-names");
        if (reg.val.length % 16 != 0) throw new IllegalArgumentException("Format reg performance-controller tidak dikenal");
        int entries = reg.val.length / 16;
        String nm = names == null ? "" : new String(names.val, java.nio.charset.StandardCharsets.UTF_8);
        if (nm.contains("performance-domain2") || entries >= 3) return;
        if (entries < 2) throw new IllegalArgumentException("performance-controller hanya punya " + entries + " domain");
        int last = (entries - 1) * 16;
        long addr = be64(reg.val, last);
        long size = be64(reg.val, last + 8);
        byte[] nr = Arrays.copyOf(reg.val, reg.val.length + 16);
        putBe64(nr, reg.val.length, addr + size);
        putBe64(nr, reg.val.length + 8, size);
        reg.val = nr;
        byte[] add = "performance-domain2".getBytes(java.nio.charset.StandardCharsets.UTF_8);
        byte[] nn = new byte[(names == null ? 0 : names.val.length) + add.length + 1];
        if (names != null) System.arraycopy(names.val, 0, nn, 0, names.val.length);
        System.arraycopy(add, 0, nn, nn.length - add.length - 1, add.length);
        pc.set("reg-names", nn);
    }

    // ---------- bagian DTB (raw FDT atau tabel DTBO) ----------
    static byte[] patchSection(byte[] sec, int[] cl) {
        int m = be32(sec, 0);
        if (m == Fdt.MAGIC) {
            Fdt f = Fdt.parse(sec, 0);
            patchTree(f, cl);
            return f.serialize();
        }
        if (m != 0xd7b7ab1e) throw new IllegalArgumentException("Format bagian DTB tidak dikenal");
        int entSize = be32(sec, 12), cnt = be32(sec, 16), entOff = be32(sec, 20);
        int hdrLen = entOff + cnt * entSize;
        byte[][] blob = new byte[cnt][];
        boolean any = false;
        for (int i = 0; i < cnt; i++) {
            int eo = entOff + i * entSize;
            int size = be32(sec, eo), off = be32(sec, eo + 4);
            byte[] raw = Arrays.copyOfRange(sec, off, off + size);
            if (raw.length >= 4 && be32(raw, 0) == Fdt.MAGIC) {
                Fdt f = Fdt.parse(raw, 0);
                if (f.root.kid("cpus") != null) {
                    patchTree(f, cl);
                    raw = f.serialize();
                    any = true;
                }
            }
            blob[i] = raw;
        }
        if (!any) throw new IllegalArgumentException("Node /cpus tidak ditemukan di DTB");
        int pos = hdrLen;
        int[] offs = new int[cnt];
        for (int i = 0; i < cnt; i++) {
            pos = (pos + 3) & ~3;
            offs[i] = pos;
            pos += blob[i].length;
        }
        byte[] out = new byte[pos];
        System.arraycopy(sec, 0, out, 0, hdrLen);
        for (int i = 0; i < cnt; i++) {
            int eo = entOff + i * entSize;
            putBe32(out, eo, blob[i].length);
            putBe32(out, eo + 4, offs[i]);
            System.arraycopy(blob[i], 0, out, offs[i], blob[i].length);
        }
        putBe32(out, 4, pos);
        return out;
    }

    // ---------- konversi utama ----------
    /** @param cl cluster (0 kecil, 1 tengah, 2 besar) untuk tiap core, urut cpu0..cpuN. */
    public static byte[] convert(byte[] img, int[] cl) {
        Layout l = layout(img);
        byte[] sec = Arrays.copyOfRange(img, l.oDtb, l.oDtb + l.dtbSize);
        byte[] ns = patchSection(sec, cl);
        return replaceSection(img, l, ns);
    }

    static byte[] replaceSection(byte[] img, byte[] ns) {
        return replaceSection(img, layout(img), ns);
    }

    private static byte[] replaceSection(byte[] img, Layout l, byte[] ns) {
        int newSlot = align(ns.length, l.page);
        int delta = newSlot - l.oldSlot;
        byte[] out = img.clone();
        if (delta != 0) {
            int len = img.length;
            boolean avb = len >= 64 && "AVBf".equals(new String(img, len - 64, 4));
            int movEnd, limit;
            if (avb) {
                long vbOff = be64(img, len - 64 + 20);
                long vbSize = be64(img, len - 64 + 28);
                movEnd = (int) (vbOff + vbSize);
                limit = len - 64;
            } else {
                int e = len;
                while (e > 0 && img[e - 1] == 0) e--;
                movEnd = e;
                limit = len;
            }
            if (movEnd < l.oAfter) movEnd = l.oAfter;
            if (movEnd + delta > limit) {
                throw new IllegalArgumentException("DTB baru tidak muat di image (selisih " + delta + " byte)");
            }
            System.arraycopy(img, l.oAfter, out, l.oAfter + delta, movEnd - l.oAfter);
            if (delta < 0) Arrays.fill(out, movEnd + delta, movEnd, (byte) 0);
            if (avb) {
                long orig = be64(img, len - 64 + 12);
                long vbOff = be64(img, len - 64 + 20);
                putBe64(out, len - 64 + 12, orig + delta);
                putBe64(out, len - 64 + 20, vbOff + delta);
            }
        }
        Arrays.fill(out, l.oDtb, l.oDtb + newSlot, (byte) 0);
        System.arraycopy(ns, 0, out, l.oDtb, ns.length);
        putLe32(out, 2100, ns.length);
        return out;
    }
}
